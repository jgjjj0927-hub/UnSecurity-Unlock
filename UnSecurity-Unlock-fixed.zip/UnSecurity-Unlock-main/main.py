import sys
from core.logger import logger

def main():
    """Запуск приложения без скрытого автозапуска и самовосстановления."""
    try:
        from ui.app import run as run_gui
        run_gui()
    except Exception:
        logger.exception("GUI failed, falling back to CLI")
        try:
            from ui.cli import run as run_cli
            run_cli()
        except Exception:
            logger.exception("CLI failed")

if __name__ == "__main__":
    main()
