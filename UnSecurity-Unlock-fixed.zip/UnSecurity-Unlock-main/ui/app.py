import threading
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

from core import scanner, startup, quarantine, defender, firmware, vault
from core.icon import icon_path

BG = "#11151c"
PANEL = "#191f29"
PANEL_ALT = "#202936"
TEXT = "#e7edf5"
MUTED = "#94a3b8"
ACCENT = "#6c9cff"
BORDER = "#2b3544"


def ask_master_password(root, create=False):
    if create:
        p1 = simpledialog.askstring("Защита карантина", "Создайте мастер-пароль (от 10 символов):", show="*", parent=root)
        if not p1:
            return None
        p2 = simpledialog.askstring("Защита карантина", "Повторите пароль:", show="*", parent=root)
        if p1 != p2:
            messagebox.showerror("Ошибка", "Пароли не совпадают.", parent=root)
            return None
        try:
            vault.init_master(p1)
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc), parent=root)
            return None
        messagebox.showinfo("Готово", "Мастер-пароль создан. Сохраните его в надёжном месте.", parent=root)
        return p1
    p = simpledialog.askstring("Защита карантина", "Введите мастер-пароль:", show="*", parent=root)
    if not p:
        return None
    if not vault.verify_master(p):
        messagebox.showerror("Ошибка", "Неверный мастер-пароль.", parent=root)
        return None
    return p


class UnSecurityApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("UnSecurity Unlock")
        self.geometry("1120x720")
        self.minsize(900, 580)
        self.configure(bg=BG)
        icon = icon_path()
        if icon:
            try:
                self.iconbitmap(str(icon))
            except Exception:
                pass
        self.findings = []
        self._row_paths = {}
        self._quar_paths = {}
        self._setup_style()
        self._build_ui()
        self.on_refresh_quarantine()
        if not vault.is_initialized():
            self.after(300, lambda: ask_master_password(self, create=True))

    def _setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 10))
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("TLabel", background=BG, foreground=TEXT)
        style.configure("Muted.TLabel", background=BG, foreground=MUTED)
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 21, "bold"))
        style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("TButton", background=PANEL_ALT, foreground=TEXT, borderwidth=0, padding=(13, 9))
        style.map("TButton", background=[("active", "#2a3749"), ("disabled", PANEL)])
        style.configure("Accent.TButton", background=ACCENT, foreground="#0c1420", font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#8ab0ff")])
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(18, 10), borderwidth=0)
        style.map("TNotebook.Tab", background=[("selected", PANEL_ALT)], foreground=[("selected", TEXT)])
        style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=30, borderwidth=0)
        style.configure("Treeview.Heading", background=PANEL_ALT, foreground=MUTED, font=("Segoe UI", 9, "bold"), padding=8)
        style.map("Treeview", background=[("selected", "#30476a")], foreground=[("selected", TEXT)])
        style.configure("TScrollbar", background=PANEL, troughcolor=BG, borderwidth=0, arrowsize=12)

    def _build_ui(self):
        header = ttk.Frame(self, padding=(24, 20, 24, 12))
        header.pack(fill="x")
        title_area = ttk.Frame(header)
        title_area.pack(side="left", fill="x", expand=True)
        ttk.Label(title_area, text="UnSecurity", style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_area, text="UNLOCK  /  ЛОКАЛЬНАЯ ПРОВЕРКА БЕЗОПАСНОСТИ", style="Subtitle.TLabel").pack(anchor="w", pady=(3, 0))
        self.status_var = tk.StringVar(value="Готов к работе")
        ttk.Label(header, textvariable=self.status_var, style="Muted.TLabel").pack(side="right", anchor="e", padx=(8, 0))

        actions = ttk.Frame(self, padding=(20, 4, 20, 14))
        actions.pack(fill="x")
        ttk.Button(actions, text="Запустить проверку", style="Accent.TButton", command=self.on_scan_all).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Автозагрузка", command=self.on_scan_startup).pack(side="left", padx=4)
        ttk.Button(actions, text="Состояние Defender", command=self.on_defender).pack(side="left", padx=4)
        ttk.Button(actions, text="Проверка прошивки", command=self.on_firmware).pack(side="left", padx=4)

        self.count_var = tk.StringVar(value="0")
        summary = ttk.Frame(self, padding=(20, 0, 20, 12))
        summary.pack(fill="x")
        card = tk.Frame(summary, bg=PANEL, highlightbackground=BORDER, highlightthickness=1, padx=16, pady=12)
        card.pack(fill="x")
        tk.Label(card, text="НАЙДЕНО ПОДОЗРИТЕЛЬНЫХ ОБЪЕКТОВ", bg=PANEL, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(card, textvariable=self.count_var, bg=PANEL, fg=TEXT, font=("Segoe UI", 25, "bold")).pack(anchor="w", pady=(2, 0))

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=20, pady=(0, 16))
        scan_tab = ttk.Frame(nb, padding=10)
        nb.add(scan_tab, text="  Результаты  ")
        columns = ("score", "name", "path", "reasons")
        self.tree = ttk.Treeview(scan_tab, columns=columns, show="headings")
        for col, label in (("score", "Оценка"), ("name", "Объект"), ("path", "Расположение"), ("reasons", "Почему отмечен")):
            self.tree.heading(col, text=label)
        self.tree.column("score", width=75, anchor="center", stretch=False)
        self.tree.column("name", width=170)
        self.tree.column("path", width=400)
        self.tree.column("reasons", width=360)
        self._attach_scroll(self.tree, scan_tab)
        ttk.Button(scan_tab, text="Зашифровать выбранный файл в карантин", command=self.on_quarantine).pack(anchor="e", pady=(10, 0))

        q_tab = ttk.Frame(nb, padding=10)
        nb.add(q_tab, text="  Карантин  ")
        self.q_tree = ttk.Treeview(q_tab, columns=("name", "size"), show="headings")
        self.q_tree.heading("name", text="Зашифрованный объект")
        self.q_tree.heading("size", text="Размер, байт")
        self.q_tree.column("name", width=650)
        self.q_tree.column("size", width=130, anchor="center")
        self._attach_scroll(self.q_tree, q_tab)
        q_actions = ttk.Frame(q_tab)
        q_actions.pack(fill="x", pady=(10, 0))
        ttk.Button(q_actions, text="Обновить", command=self.on_refresh_quarantine).pack(side="left")
        ttk.Button(q_actions, text="Восстановить файл…", command=self.on_restore).pack(side="left", padx=8)

        footer = ttk.Frame(self, padding=(20, 0, 20, 12))
        footer.pack(fill="x")
        ttk.Label(footer, text="Эвристическая проверка не заменяет полноценный антивирус.", style="Muted.TLabel").pack(anchor="w")

    @staticmethod
    def _attach_scroll(tree, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        tree.pack(in_=frame, side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

    def on_scan_all(self):
        self.status_var.set("Идёт проверка…")
        self._clear_tree()
        self.count_var.set("…")
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            roots = scanner.get_scan_roots()
            findings = scanner.scan_paths(roots, progress_cb=self._progress_cb)
            self.after(0, self._populate_tree, findings)
            self.after(0, self.status_var.set, "Проверка завершена")
        except Exception as exc:
            self.after(0, self.status_var.set, "Ошибка проверки")
            self.after(0, messagebox.showerror, "Ошибка сканирования", str(exc))

    def _progress_cb(self, scanned, current):
        self.after(0, self.status_var.set, f"Проверено файлов: {scanned:,}  ·  {current[-55:]}")

    def on_scan_startup(self):
        self.status_var.set("Проверка автозагрузки…")
        results = []
        for entry in startup.get_startup_entries():
            command = entry["command"].strip()
            low = command.lower()
            reasons = []
            if any(part in low for part in ("\\temp\\", "\\downloads\\", "\\appdata\\local\\temp\\")):
                reasons.append("Команда запуска указывает на пользовательскую/временную папку")
            if not reasons:
                reasons.append("Запись автозагрузки требует ручной проверки")
            results.append({"path": command, "name": entry["name"], "score": len(reasons), "reasons": "; ".join(reasons)})
        self._populate_tree(results)
        self.status_var.set(f"Записей автозагрузки: {len(results)}")

    def on_quarantine(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Карантин", "Сначала выберите файл в результатах.")
            return
        path = self._row_paths.get(selected[0])
        if not path or not messagebox.askyesno("Подтверждение", "Файл будет зашифрован и удалён из исходного расположения. Продолжить?"):
            return
        password = ask_master_password(self)
        if not password:
            return
        try:
            target = quarantine.quarantine_file(path, password)
            messagebox.showinfo("Карантин", f"Файл помещён в карантин:\n{target}")
            self.on_refresh_quarantine()
            self.on_scan_all()
        except Exception as exc:
            messagebox.showerror("Не удалось поместить в карантин", str(exc))

    def on_defender(self):
        messagebox.showinfo("Microsoft Defender", f"Защита в реальном времени: {defender.check_defender_status()}\n\nПриложение не меняет настройки Defender.")

    def on_firmware(self):
        self.status_var.set("Проверка параметров прошивки…")
        try:
            data = firmware.check_firmware()
            warn = firmware.firmware_warning()
            msg = (f"Режим прошивки: {data['firmware_type']}\nSecure Boot: {data['secure_boot']}\nTPM: {data['tpm']}\nSHA-256 загрузчика: {data['bootloader_sha256'] or 'не найден'}\n\n")
            msg += warn or "Критичных замечаний по доступным параметрам нет."
            messagebox.showinfo("Проверка прошивки", msg)
            self.status_var.set("Проверка прошивки завершена")
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc))
            self.status_var.set("Ошибка проверки прошивки")

    def on_refresh_quarantine(self):
        for item in self.q_tree.get_children():
            self.q_tree.delete(item)
        self._quar_paths.clear()
        try:
            for item in quarantine.list_quarantine():
                iid = self.q_tree.insert("", "end", values=(item["name"], item["size"]))
                self._quar_paths[iid] = item["name"]
        except Exception as exc:
            messagebox.showerror("Карантин", str(exc))

    def on_restore(self):
        selected = self.q_tree.selection()
        if not selected:
            messagebox.showinfo("Восстановление", "Выберите объект в карантине.")
            return
        name = self._quar_paths.get(selected[0])
        password = ask_master_password(self)
        if not name or not password:
            return
        base = name.split("_", 2)[-1].removesuffix(".quar")
        target = simpledialog.askstring("Восстановление", "Укажите полный путь для восстановления:", initialvalue=str(__import__("pathlib").Path.home() / "Restored" / base), parent=self)
        if not target:
            return
        try:
            out = quarantine.restore_file(name, target, password)
            messagebox.showinfo("Восстановлено", f"Файл сохранён:\n{out}")
            self.on_refresh_quarantine()
        except Exception as exc:
            messagebox.showerror("Ошибка восстановления", str(exc))

    def _clear_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._row_paths.clear()

    def _populate_tree(self, findings):
        self._clear_tree()
        self.findings = findings
        for finding in sorted(findings, key=lambda item: item["score"], reverse=True):
            iid = self.tree.insert("", "end", values=(finding["score"], finding["name"], finding["path"], finding["reasons"]))
            self._row_paths[iid] = finding["path"]
        self.count_var.set(str(len(findings)))


def run():
    app = UnSecurityApp()
    app.mainloop()
