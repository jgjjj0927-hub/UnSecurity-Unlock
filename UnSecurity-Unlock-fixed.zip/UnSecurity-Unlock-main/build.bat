@echo off
setlocal
cd /d "%~dp0"
echo === UnSecurity Unlock build ===
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed.
  pause
  exit /b 1
)
python -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=tk-inter ^
  --windows-console-mode=disable ^
  --windows-icon-from-ico=assets\icon-2.ico ^
  --include-data-dir=assets=assets ^
  --output-filename=UnSecurityUnlock.exe ^
  --assume-yes-for-downloads ^
  --remove-output ^
  --output-dir=dist ^
  main.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo Build complete: dist\UnSecurityUnlock.exe
pause
