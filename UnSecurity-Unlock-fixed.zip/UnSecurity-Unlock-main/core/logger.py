import logging
import os
from pathlib import Path

def _log_dir():
    base = os.getenv("LOCALAPPDATA") or os.getenv("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    path = Path(base) / "UnSecurityUnlock" / "logs"
    try:
        path.mkdir(parents=True, exist_ok=True)
        return path
    except OSError:
        fallback = Path.home() / ".unsecurityunlock" / "logs"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

LOG_DIR = _log_dir()
logger = logging.getLogger("unsecurity_unlock")
logger.setLevel(logging.INFO)
if not logger.handlers:
    fh = logging.FileHandler(LOG_DIR / "unsecurity_unlock.log", encoding="utf-8")
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    logger.addHandler(fh)
