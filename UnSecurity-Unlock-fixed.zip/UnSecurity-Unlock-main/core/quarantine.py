import os
import shutil
import time
from pathlib import Path
from typing import List, Dict, Optional

from . import vault
from .logger import logger

QUARANTINE_DIR = vault.VAULT_DIR

_ALLOWED_ROOT = str(QUARANTINE_DIR.resolve())


def _safe_quarantine_target(name: str) -> Path:
    dest = (QUARANTINE_DIR / name).resolve()
    try:
        dest.relative_to(QUARANTINE_DIR.resolve())
    except ValueError:
        raise ValueError("Недопустимое имя файла карантина")
    if Path(name).name != name or name in {".", ".."}:
        raise ValueError("Недопустимое имя файла карантина")
    return dest


def quarantine_file(path: str, password: str) -> str:
    """Зашифровать файл и поместить в карантин."""
    src = Path(path)
    if not src.exists():
        raise FileNotFoundError(path)

    key = vault.get_key(password)
    if key is None:
        raise PermissionError("неверный мастер-пароль")

    ts = time.strftime("%Y%m%d_%H%M%S")
    safe_name = f"{ts}_{src.name}.quar"
    dest = _safe_quarantine_target(safe_name)

    try:
        raw = src.read_bytes()
        blob = vault.encrypt_blob(key, raw)
        # Сначала сохраняем зашифрованную копию и проверяем её, затем удаляем оригинал.
        temp_dest = dest.with_suffix(dest.suffix + ".tmp")
        temp_dest.write_bytes(blob)
        if vault.decrypt_blob(key, temp_dest.read_bytes()) != raw:
            temp_dest.unlink(missing_ok=True)
            raise IOError("Проверка зашифрованной копии не пройдена")
        os.replace(temp_dest, dest)
        try:
            src.unlink()
        except OSError as e:
            logger.warning("Оригинал оставлен на месте: %s", e)
        logger.info("quarantined %s -> %s", src, dest)
        return str(dest)
    except Exception as e:
        logger.error("quarantine failed for %s: %s", src, e)
        raise


def restore_file(quarantine_name: str, original_path: str, password: str) -> str:
    """Расшифровать и восстановить оригинал."""
    src = _safe_quarantine_target(quarantine_name)
    if not src.exists():
        raise FileNotFoundError(quarantine_name)

    key = vault.get_key(password)
    if key is None:
        raise PermissionError("неверный мастер-пароль")

    blob = src.read_bytes()
    raw = vault.decrypt_blob(key, blob)

    dest = Path(original_path).expanduser()
    if dest.exists():
        raise FileExistsError(f"Файл уже существует: {dest}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp_dest = dest.with_name(dest.name + ".unsec-tmp")
    temp_dest.write_bytes(raw)
    os.replace(temp_dest, dest)
    try:
        os.remove(str(src))
    except OSError:
        pass
    logger.info("restored %s -> %s", src, dest)
    return str(dest)


def run_from_quarantine(quarantine_name: str, password: str) -> None:
    """Запуск из карантина намеренно отключён: карантин не должен исполнять файлы."""
    raise PermissionError("Запуск файлов из карантина отключён. Сначала восстановите файл в отдельную папку и проверьте его.")


def list_quarantine() -> List[Dict]:
    items = []
    for f in QUARANTINE_DIR.iterdir():
        if f.is_file() and f.name != ".master":
            items.append({
                "name": f.name,
                "size": f.stat().st_size,
                "path": str(f),
            })
    return items
