import subprocess
from typing import List

def check_defender_status() -> str:
    """Read-only check of Microsoft Defender real-time protection."""
    try:
        p = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "(Get-MpComputerStatus -ErrorAction Stop).RealTimeProtectionEnabled"],
            capture_output=True, text=True, timeout=20, check=False
        )
        if p.returncode == 0:
            value = p.stdout.strip().lower()
            return "Включена" if value == "true" else "Выключена" if value == "false" else "Неизвестно"
    except Exception:
        pass
    return "Недоступно"
